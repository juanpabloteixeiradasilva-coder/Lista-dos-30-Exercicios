codigos = [101, 105, 110, 120, 135, 150, 180, 200]

codigo = int(input("Digite o código do livro: "))

inicio = 0
fim = len(codigos) - 1
posicao = -1

while inicio <= fim:
    meio = (inicio + fim) // 2

    if codigos[meio] == codigo:
        posicao = meio
        break
    elif codigo < codigos[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

if posicao != -1:
    print("Livro disponível.")
    print("Posição:", posicao)
else:
    print("Livro não encontrado.")