notas = [7.0, 8.5, 6.0, 7.0, 9.0, 7.0]

nota = float(input("Digite uma nota: "))

quantidade = 0

for valor in notas:
    if valor == nota:
        quantidade += 1

if quantidade > 0:
    print("A nota aparece na lista.")
    print("Quantidade de vezes:", quantidade)
else:
    print("A nota não aparece na lista.")