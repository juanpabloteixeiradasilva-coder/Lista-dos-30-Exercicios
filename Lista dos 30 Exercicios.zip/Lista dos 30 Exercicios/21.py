numeros = [2, 5, 5, 5, 8, 10, 10, 15, 20]

valor = int(input("Digite um valor: "))

inicio = 0
fim = len(numeros) - 1
posicao = -1

while inicio <= fim:
    meio = (inicio + fim) // 2

    if numeros[meio] == valor:
        posicao = meio
        break
    elif valor < numeros[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

if posicao != -1:
    print("Valor encontrado no índice:", posicao)
else:
    print("Valor não encontrado.")