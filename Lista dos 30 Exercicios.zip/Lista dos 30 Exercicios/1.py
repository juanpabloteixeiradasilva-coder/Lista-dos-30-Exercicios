numeros = [10, 25, 7, 32, 18, 4, 50, 13, 9, 21]

numero = int(input("Digite um número: "))

encontrado = False

for valor in numeros:
    if valor == numero:
        encontrado = True
        break

if encontrado:
    print("O número está na lista.")
else:
    print("O número não está na lista.")