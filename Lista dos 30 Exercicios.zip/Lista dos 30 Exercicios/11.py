cpfs = ["111.111.111-11", "222.222.222-22", "333.333.333-33", "444.444.444-44"]

cpf = input("Digite o CPF: ")

comparacoes = 0
encontrado = False

for valor in cpfs:
    comparacoes += 1

    if valor == cpf:
        encontrado = True
        break

if encontrado:
    print("CPF cadastrado.")
else:
    print("CPF não cadastrado.")

print("Comparações realizadas:", comparacoes)