produtos = ["Arroz", "Feijão", "Leite", "Café", "Açúcar"]
precos = [25.90, 8.50, 6.20, 15.00, 5.80]

produto = input("Digite o nome do produto: ")

posicao = -1

for i in range(len(produtos)):
    if produtos[i].lower() == produto.lower():
        posicao = i
        break

if posicao != -1:
    print("Produto encontrado.")
    print("Preço: R$", precos[posicao])
else:
    print("Produto não encontrado.")