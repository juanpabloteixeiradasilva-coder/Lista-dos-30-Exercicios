codigos = [100, 120, 150, 180, 200, 250, 300, 350]

codigo = int(input("Digite o código do produto: "))

inicio = 0
fim = len(codigos) - 1
encontrado = False

while inicio <= fim:
    meio = (inicio + fim) // 2

    if codigos[meio] == codigo:
        encontrado = True
        break
    elif codigo < codigos[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

if encontrado:
    print("Produto cadastrado.")
else:
    print("Produto não cadastrado.")