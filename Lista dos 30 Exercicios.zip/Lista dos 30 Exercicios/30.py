lista = []
ordenada = False

while True:
    print("\n--- MENU ---")
    print("1 - Cadastrar valor")
    print("2 - Exibir lista")
    print("3 - Ordenar lista")
    print("4 - Busca sequencial")
    print("5 - Busca binária")
    print("0 - Sair")

    opcao = input("Escolha uma opção: ")

    if opcao == "1":
        valor = int(input("Digite o valor: "))
        lista.append(valor)
        ordenada = False

        print("Valor cadastrado.")

    elif opcao == "2":
        print("Lista:", lista)

    elif opcao == "3":
        lista.sort()
        ordenada = True

        print("Lista ordenada:", lista)

    elif opcao == "4":
        valor = int(input("Digite o valor que deseja procurar: "))

        posicao = -1

        for i in range(len(lista)):
            if lista[i] == valor:
                posicao = i
                break

        if posicao != -1:
            print("Valor encontrado na posição:", posicao)
        else:
            print("Valor não encontrado.")

    elif opcao == "5":
        if not ordenada:
            print("A lista precisa estar ordenada para realizar a busca binária.")

        else:
            valor = int(input("Digite o valor que deseja procurar: "))

            inicio = 0
            fim = len(lista) - 1
            posicao = -1

            while inicio <= fim:
                meio = (inicio + fim) // 2

                if lista[meio] == valor:
                    posicao = meio
                    break

                elif valor < lista[meio]:
                    fim = meio - 1

                else:
                    inicio = meio + 1

            if posicao != -1:
                print("Valor encontrado na posição:", posicao)
            else:
                print("Valor não encontrado.")

    elif opcao == "0":
        print("Programa encerrado.")
        break

    else:
        print("Opção inválida.")