palavras = ["casa", "computador", "python", "universidade", "livro"]

maior_palavra = palavras[0]

for palavra in palavras:
    if len(palavra) > len(maior_palavra):
        maior_palavra = palavra

print("Palavra com mais caracteres:", maior_palavra)