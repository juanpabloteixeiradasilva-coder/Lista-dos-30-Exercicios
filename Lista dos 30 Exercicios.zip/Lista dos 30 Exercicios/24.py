idades = [10, 12, 14, 16, 18, 20, 22, 25, 30, 35]

idade = int(input("Digite uma idade: "))

inicio = 0
fim = len(idades) - 1
descartados = 0
encontrado = False

while inicio <= fim:
    meio = (inicio + fim) // 2

    if idades[meio] == idade:
        encontrado = True
        break

    elif idade < idades[meio]:
        descartados += fim - meio
        fim = meio - 1

    else:
        descartados += meio - inicio + 1
        inicio = meio + 1

if encontrado:
    print("Idade encontrada.")
else:
    print("Idade não encontrada.")

print("Elementos descartados:", descartados)