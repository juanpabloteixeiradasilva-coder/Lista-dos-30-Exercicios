numeros = [5, 10, 15, 20, 25, 30, 35, 40]

valor = int(input("Digite o valor: "))

inicio = 0
fim = len(numeros) - 1
comparacoes = 0
encontrado = False

while inicio <= fim:
    meio = (inicio + fim) // 2
    comparacoes += 1

    if numeros[meio] == valor:
        encontrado = True
        break
    elif valor < numeros[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

if encontrado:
    print("Valor encontrado.")
else:
    print("Valor não encontrado.")

print("Comparações realizadas:", comparacoes)