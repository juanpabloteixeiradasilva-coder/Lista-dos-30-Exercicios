nomes = ["Ana", "Bruno", "Carlos", "João", "Maria", "Pedro"]
telefones = ["9999-1111", "9999-2222", "9999-3333",
             "9999-4444", "9999-5555", "9999-6666"]

nome = input("Digite o nome do contato: ")

inicio = 0
fim = len(nomes) - 1
posicao = -1

while inicio <= fim:
    meio = (inicio + fim) // 2

    if nomes[meio].lower() == nome.lower():
        posicao = meio
        break
    elif nome.lower() < nomes[meio].lower():
        fim = meio - 1
    else:
        inicio = meio + 1

if posicao != -1:
    print("Contato:", nomes[posicao])
    print("Telefone:", telefones[posicao])
else:
    print("Contato não encontrado.")