nomes = ["Ana", "Carlos", "João", "Maria", "Pedro"]

nome = input("Digite um nome: ")

posicao = -1

for i in range(len(nomes)):
    if nomes[i].lower() == nome.lower():
        posicao = i
        break

if posicao != -1:
    print("Nome encontrado na posição:", posicao)
else:
    print("Nome não encontrado.")