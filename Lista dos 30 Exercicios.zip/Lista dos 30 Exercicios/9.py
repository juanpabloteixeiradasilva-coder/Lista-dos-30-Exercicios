matriculas = [202601, 202602, 202603, 202604, 202605]

matricula = int(input("Digite a matrícula: "))

encontrado = False

for numero in matriculas:
    if numero == matricula:
        encontrado = True
        break

if encontrado:
    print("Aluno cadastrado.")
else:
    print("Matrícula não encontrada.")