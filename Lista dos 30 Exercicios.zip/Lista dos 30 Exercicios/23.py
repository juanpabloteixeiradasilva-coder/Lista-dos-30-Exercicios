numeros = [2, 5, 5, 5, 8, 10, 10, 15]

valor = int(input("Digite um valor: "))

inicio = 0
fim = len(numeros) - 1
ultima = -1

while inicio <= fim:
    meio = (inicio + fim) // 2

    if numeros[meio] == valor:
        ultima = meio
        inicio = meio + 1
    elif valor < numeros[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

if ultima != -1:
    print("Última ocorrência no índice:", ultima)
else:
    print("Valor não encontrado.")