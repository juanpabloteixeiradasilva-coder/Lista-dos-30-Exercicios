def busca_binaria(lista, valor):
    inicio = 0
    fim = len(lista) - 1

    while inicio <= fim:
        meio = (inicio + fim) // 2

        if lista[meio] == valor:
            return True
        elif valor < lista[meio]:
            fim = meio - 1
        else:
            inicio = meio + 1

    return False


numeros = [2, 4, 6, 8, 10, 12]

valor = int(input("Digite um número: "))

print(busca_binaria(numeros, valor))