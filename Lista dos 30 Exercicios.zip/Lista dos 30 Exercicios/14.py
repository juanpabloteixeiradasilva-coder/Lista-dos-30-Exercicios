def busca_binaria(lista, valor):
    inicio = 0
    fim = len(lista) - 1

    while inicio <= fim:
        meio = (inicio + fim) // 2

        if lista[meio] == valor:
            return meio
        elif valor < lista[meio]:
            fim = meio - 1
        else:
            inicio = meio + 1

    return -1


numeros = [5, 10, 15, 20, 25, 30]

valor = int(input("Digite um valor: "))

print("Índice:", busca_binaria(numeros, valor))