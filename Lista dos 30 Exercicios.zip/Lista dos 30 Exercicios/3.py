def busca_sequencial(lista, valor):
    for i in range(len(lista)):
        if lista[i] == valor:
            return i

    return -1


numeros = [5, 8, 12, 20, 30]

valor = int(input("Digite o valor que deseja procurar: "))

resultado = busca_sequencial(numeros, valor)

print("Índice:", resultado)