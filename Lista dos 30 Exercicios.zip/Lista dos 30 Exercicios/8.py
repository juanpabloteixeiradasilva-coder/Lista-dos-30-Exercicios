def existe_numero(lista, numero):
    for valor in lista:
        if valor == numero:
            return True

    return False


numeros = [3, 7, 12, 18, 25]

numero = int(input("Digite um número: "))

print(existe_numero(numeros, numero))