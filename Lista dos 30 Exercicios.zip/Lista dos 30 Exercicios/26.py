codigos = [10, 20, 30, 40, 50, 60, 70]

codigo = int(input("Digite o código do produto: "))

# Busca sequencial
comparacoes_sequencial = 0

for valor in codigos:
    comparacoes_sequencial += 1

    if valor == codigo:
        break

# Busca binária
inicio = 0
fim = len(codigos) - 1
comparacoes_binaria = 0

while inicio <= fim:
    meio = (inicio + fim) // 2
    comparacoes_binaria += 1

    if codigos[meio] == codigo:
        break
    elif codigo < codigos[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

print("Comparações na busca sequencial:", comparacoes_sequencial)
print("Comparações na busca binária:", comparacoes_binaria)