numeros = [12, 5, 18, 30, 7, 25]

valor = int(input("Digite o valor procurado: "))

comparacoes = 0
posicao = -1

for i in range(len(numeros)):
    comparacoes += 1

    if numeros[i] == valor:
        posicao = i
        break

if posicao != -1:
    print("Valor encontrado:", valor)
    print("Posição:", posicao)
else:
    print("Valor não encontrado.")

print("Comparações:", comparacoes)