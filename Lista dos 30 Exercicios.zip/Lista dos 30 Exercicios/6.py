numeros = [15, 8, 42, 23, 4, 67, 31]

maior = numeros[0]

for numero in numeros:
    if numero > maior:
        maior = numero

print("Maior valor:", maior)