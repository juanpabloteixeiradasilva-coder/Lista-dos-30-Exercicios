matriculas = [105, 101, 120, 110, 130]

print("1 - Busca sequencial")
print("2 - Busca binária")

opcao = int(input("Escolha: "))
matricula = int(input("Digite a matrícula: "))

encontrado = False

if opcao == 1:
    for valor in matriculas:
        if valor == matricula:
            encontrado = True
            break

elif opcao == 2:
    matriculas.sort()

    inicio = 0
    fim = len(matriculas) - 1

    while inicio <= fim:
        meio = (inicio + fim) // 2

        if matriculas[meio] == matricula:
            encontrado = True
            break
        elif matricula < matriculas[meio]:
            fim = meio - 1
        else:
            inicio = meio + 1

else:
    print("Opção inválida.")

if encontrado:
    print("Aluno encontrado.")
else:
    print("Aluno não encontrado.")