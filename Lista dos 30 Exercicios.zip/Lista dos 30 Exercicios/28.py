numeros = list(range(1, 1001))

valor = numeros[-1]

# Busca sequencial
comparacoes_sequencial = 0

for numero in numeros:
    comparacoes_sequencial += 1

    if numero == valor:
        break

# Busca binária
inicio = 0
fim = len(numeros) - 1
comparacoes_binaria = 0

while inicio <= fim:
    meio = (inicio + fim) // 2
    comparacoes_binaria += 1

    if numeros[meio] == valor:
        break
    elif valor < numeros[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1

print("Busca sequencial:", comparacoes_sequencial, "comparações")
print("Busca binária:", comparacoes_binaria, "comparações")

print("\nConclusão:")
print("A busca binária realizou muito menos comparações.")
print("Isso acontece porque ela elimina parte da lista a cada busca.")