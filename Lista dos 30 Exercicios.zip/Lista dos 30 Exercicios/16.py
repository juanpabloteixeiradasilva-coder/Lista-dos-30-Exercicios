numeros = [2, 5, 8, 10, 14, 18, 22, 27, 31, 35,
           40, 45, 50, 55, 60, 65, 70, 75, 80, 90]

valor = int(input("Digite o valor procurado: "))

inicio = 0
fim = len(numeros) - 1

while inicio <= fim:
    meio = (inicio + fim) // 2

    print("Início:", inicio, "| Fim:", fim, "| Meio:", meio)

    if numeros[meio] == valor:
        print("Valor encontrado.")
        break
    elif valor < numeros[meio]:
        fim = meio - 1
    else:
        inicio = meio + 1
else:
    print("Valor não encontrado.")